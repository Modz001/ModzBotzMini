/*
Terimakasih Telah Menggunakan Script ini
Base By : ErizaOffc
Optimalization By : Modz

Dukung Kami Dengan Membiarkan Credit Ini Tetap Ada!
*/

const fs = require('fs')
const chalk = require('chalk')

//Settings
global.owner = "6283163234218"
global.ownername = "Modz"
global.namabot = "Modz Botz"
global.botversion = "V1"
global.linkgc = "https://chat.whatsapp.com/IZ4dN1Oa5fsLL50qYGcfYD"
global.idGc = "120363308440213757@g.us"
global.linkSaluran = "https://whatsapp.com/channel/0029Vb4KdTa1XquUTOZoEf3D"
global.idSaluran = "120363379975415016@newsletter"
global.namaSaluran = global.ownername + " | Saluran WhatsApp"
global.simbol = "⌬"

//Thumbnail
global.imgthumb = "https://files.catbox.moe/8381kq.jpg"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})